<footer class="main-footer">
    <div class="pull-right hidden-xs">
        
    </div>
    <strong>BACKEND &copy; <?= date('Y'); ?>. BD211</strong>
    
</footer>