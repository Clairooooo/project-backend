<?php

header("location: dashboard");
