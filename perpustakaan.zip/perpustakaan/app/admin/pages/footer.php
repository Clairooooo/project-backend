<footer class="main-footer">
    <div class="pull-right hidden-xs">
 
    </div>
    <strong>backend &copy; <?= date('Y'); ?>.</strong> BD211 <a></a>
    
</footer>